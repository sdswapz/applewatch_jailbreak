//
//  Header.h
//  jailbreak
//
//  Created by Swapnil on 11/2/17.
//  Copyright © 2017 SwapnilMe. All rights reserved.
//

#ifndef Header_h
#define Header_h

int jail()

#endif /* Header_h */
